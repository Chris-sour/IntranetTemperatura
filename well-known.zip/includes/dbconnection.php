<?php
$con=mysqli_connect("localhost", "especial_cgonzales", "S3gur1dad2021", "especial_intranet");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

  ?>
